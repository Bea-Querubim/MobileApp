import 'package:flutter/material.dart';

class ShowItemPage extends StatelessWidget{
  late final _todoItem;

  ShowItemPage({required todoItem})
  :_todoItem = todoItem;

  Widget build(BuildContext context){
    return Scaffold(
      appBar:  AppBar(),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Text(
          _todoItem.description)
          )
      );
  }

}