import 'package:aula03_mobile/pages/Widget/show_item_page.dart';
import 'package:aula03_mobile/pages/model/todo_item.dart';
import 'package:flutter/material.dart';

class TodoListView extends StatelessWidget {
  late final List<TodoItem>_todos;

  TodoListView({required todos}) : _todos = todos;

  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: _todos.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text("${_todos[index].title}"),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) {
                  return ShowItemPage(
                    todoItem: _todos[index]
                    );
                },
              ),
            );
          },
        );
      },
    );
  }
}
