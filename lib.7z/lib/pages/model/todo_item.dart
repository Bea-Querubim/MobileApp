class TodoItem{
  late final String _title;
  late final String _description;
// final em tempo de execução nao podem ser mais alteradas!
//late final -> é para que apos buildar e inicializar a variavel, e for atribuido o valor, nao se pode mais ser alterado. 

  TodoItem ({ required String title,
              required String description})
                /*{
                this._title = title;
                this._description = description;
                }
                */
                : _title = title,
                _description = description;
              

  String get title => _title;
  String get description => _description;
} 
