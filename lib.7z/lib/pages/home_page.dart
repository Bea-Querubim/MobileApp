import 'package:aula03_mobile/Widget/todo_list_view.dart';
import 'package:aula03_mobile/pages/model/todo_item.dart';
import 'package:flutter/material.dart';

/*
class HomePage extends StatelessWidget{

  Widget build(BuildContext context){
    return Scaffold(
      body: Center(
        child: ElevatedButton(
          onPressed: (){
            //Abre a Route/tela/pagina RandomPage
            Navigator.push(context,
            MaterialPageRoute(
              builder: (context) => RandomPage(),
              )
            );
        },
         child: Text("Random")
         
         ),
      ),
    );
  }
}
*/

class HomePage extends StatelessWidget{
  late final todos;

  HomePage(){
    todos = List.generate(50, (index){
      TodoItem(
        title: "Item $index",
        description: "Descricao do Item: $index"
        );
      }
    );
  }

  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(),
      body: TodoListView(todos: todos),
    );
  }
}